import java.util.*; 
import java.io.*; 

public class GetawayPath {
	

  /** This is for you to fill out. 
	* @param matrix is a 2D array of integers
	* @return a single integer denoting the length of the longest path. 
	*/
	public static int longestPath(int[][] matrix) {
			int result = -1;
		    return result;
	}
  // Make sure none of this has changed before submitting!
	public static void main(String[] args) throws IOException {
		Scanner sc = new Scanner(new FileReader("GetawayPathIN.txt"));
		while (sc.hasNext()) {
			int N = sc.nextInt();
			int matrix[][] = new int[N][N];

			for (int i = 0; i < N; i++) {
				for (int j = 0; j < N; j++) { 
					matrix[i][j] = sc.nextInt();
				}
			}
			System.out.println(longestPath(matrix));	    
		}
	}

}
