def anagram_tester(word_list):
    """

    :param word_list: list of words
    :return: largest set of words that are all anagrams in alphabetical order
    """

    # TODO: implement
    return []


def parse_file_and_call_function():
    with open("TreasonsIN.txt", "r") as f:
        line = f.readline()
        test_cases = line.split('|')
        for test_case in test_cases:
            test_case = [s for s in test_case.split(' ') if len(s.strip()) > 0]
            if len(test_case) > 0:
                ans = anagram_tester(test_case)
                print '[{}]'.format(', '.join(ans))


if __name__ == "__main__":
    parse_file_and_call_function()
