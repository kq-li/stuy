# Fill out the body of this method
# All inputs are integers and you should fill A, and B with the amount of each crop
# you should grow
def get_crop_amounts(A_water, A_labor, B_water, B_labor, total_water, total_labor):
    A, B = 0, 0
    return A, B
    
if __name__ == "__main__":
    with open("FastidiousFarmingIN.txt", "r") as f:
        while True:
            s = f.readline()
            if s == '':
                break
            A_water, A_labor = [int(x) for x in s.split(" ")]
            B_water, B_labor = [int(x) for x in f.readline().split(" ")]
            total_water, total_labor = [int(x) for x in f.readline().split(" ")]
            A, B = get_crop_amounts(A_water, A_labor, B_water, B_labor, total_water, total_labor)
            print "%d %d" % (A, B)
