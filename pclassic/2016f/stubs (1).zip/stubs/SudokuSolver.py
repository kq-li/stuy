def sudoku_solver(puzzle):
    """

    :param puzzle: a 9 x 9 grid (list of lists) of integers denoting the unsolved puzzle
    :return: a 9 x 9 grid (list of lists) of integers denoting the solved puzzle
    """
    # TODO: implement
    return None


def parse_file_and_call_function():
    with open("SudokuSolverIN.txt", "r") as f:
        puzzles = []
        current_puzzle = []
        for line in f:
            line = line.strip()
            if len(line) > 0:
                current_puzzle.append([int(x) for x in line.split()])
                if len(current_puzzle) == 9:
                    puzzles.append(current_puzzle)
                    current_puzzle = []

        for puzzle in puzzles:
            ans = sudoku_solver(puzzle)
            out = ''
            for line in ans:
                out += ' '.join([str(x) for x in line])
                out += '\n'
            print out


if __name__ == "__main__":
    parse_file_and_call_function()
