# M is the number of ports.
# ships is a list of lists, each list represents the stops for one ship
# start and end are the IDs of the start and end port respectively
def minimum_stops(M, ships, start, end):
    stops = 0
    return stops

if __name__ == "__main__":
    with open("MinimizingIN.txt", "r") as f:
        while True:
            s = f.readline()
            if s == '':
                break
            N, M, S, E = [int(x) for x in s.split()]
            ships = []
            for i in range(N):
                ships.append([int(x) for x in f.readline().split()])
            print(minimum_stops(M, ships, S, E))
