def time_travel_tree_traversal(splits):
    """

    :param splits: a list of tuples where each tuple is an (a, b, c) int triple
                   indicating that timeline a spawned timelines b and c
    :return: an integer indicating the largest distance between two timelines
    """

    # TODO: implement
    return -1


def parse_file_and_call_function():
    with open("TimeTravelTreeTraversalIN.txt", "r") as f:
        while True:
            start_test_case = f.readline()
            if not start_test_case:
                break
            num_lines = int(start_test_case)
            splits = []
            for i in xrange(num_lines):
                root, left, right = f.readline().split()
                splits.append((int(root), int(left), int(right)))
            print time_travel_tree_traversal(splits)


if __name__ == '__main__':
    parse_file_and_call_function()
